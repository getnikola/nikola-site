# -*- encoding:utf-8 -*-

MESSAGES = {
    u"LANGUAGE": u"Français",
    u"Posts for year %s": u"Billets de l'année %s",
    u"Archive": u"Archives",
    u"Posts about %s:": u"Billets sur %s",
    u"Tags": u"Étiquettes",
    u"Also available in: ": u"Disponible aussi en : ",
    u"More posts about": u"Plus de billets sur",
    u"Posted:": u"Publié :",
    u"Original site": u"Site d'origine",
    u"Read in english": u"Lire en français",
}
