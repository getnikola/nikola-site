# -*- encoding:utf-8 -*-

MESSAGES = {
    u"LANGUAGE": u"Español",
    u"Posts for year %s": u"Posts del año %s",
    u"Archive": u"Archivo",
    u"Posts about %s:": u"Posts sobre %s",
    u"Tags": u"Tags",
    u"Also available in: ": u"También disponible en: ",
    u"More posts about": u"Más posts sobre",
    u"Posted:": u"Publicado:",
    u"Original site": u"Sitio original",
    u"Read in english": u"Leer en español",
}